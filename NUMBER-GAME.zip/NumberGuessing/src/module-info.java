/**
 * 
 */
/**
 * 
 */
module NumberGuessing {
}