package NumberGuessingGame;

import java.util.Random;
import java.util.Scanner;

public class NumberGuessing {

	public static void main(String[] args) {
		// print out heading for a user
		System.out.println("........................................");
		System.out.println("         Pick a number,any number,,,,");
		System.out.println("........................................");
		System.out.println();
		Random rand = new Random();
		int random_number = rand.nextInt(99) + 1;
		
		//we want to read the user input
		Scanner mykeyboard = new Scanner (System.in);
		System.out.print("Pick a number between 0 and 100 (you have 5 guesses): ");
		int guess;
		int numberOfTries = 1;  //this is the initial count of the number of guesses.
		boolean win = false;
		
		while (win == false)
		{
			guess = mykeyboard.nextInt(); //Read the input for the user to see if it matches the random number.
			
			if (numberOfTries < 5)
			{
				if (guess == random_number)
				{//if the number is guesses, the while loop is terminated 
					System.out.println();
					System.out.println("You got it! It is indeed: " + random_number);
					System.out.println("It only took you" + numberOfTries + "guesses to get it right!");
					win = true;
				}
				else if (guess < random_number)
				{//if the guess is too low, the program should tell us.
					System.out.println("You are too low!");
					System.out.println();
					System.out.println("Guess again:");	
				}
				else if (guess > random_number)
				{//if the guess is too high, the program should tell us.
					System.out.println("You are too high!");
					System.out.println();
					System.out.println("Guess again");
				}
				// Output the closing message and information to the user depending on if they guessed right on their final guess.
				else if (numberOfTries == 5)
				{
				if (guess == random_number)
				{
					System.out.println();
					System.out.println("You got it! It is indeed: " + random_number);
					System.out.println("It only took you" + numberOfTries + "guesses to get it right!");
					mykeyboard.close();
					win = true;
				}
				if (guess != random_number)
				{
					System.out.println();
					System.out.println("Sorry you ran out of attempts. The correct number is:" + random_number + "Better luck next time!");
					mykeyboard.close();
					break;
				}
			    }
				numberOfTries = numberOfTries +1;   // Increment the count of the guesses by 1	
			}
		}
		}

	}
